package com.springsecurity.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springsecurity.example.entity.Employee;
import com.springsecurity.example.repository.Employeerepo;

@Service
public class Serviceimpl {

	@Autowired
	private Employeerepo employeerepo;
	
	
	public List<Employee> getemployeedetails(){
		
		List<Employee> obj=employeerepo.findAll();
		
		return obj;
	}
}
