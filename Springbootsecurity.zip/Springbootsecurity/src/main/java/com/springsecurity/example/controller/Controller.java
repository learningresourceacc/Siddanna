package com.springsecurity.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springsecurity.example.entity.Employee;
import com.springsecurity.example.service.Serviceimpl;

@RestController
public class Controller {

//	@GetMapping("/hello")
//	
//	public String getmessage() {
//		return "hello good morning";
//	}

	@Autowired
	private Serviceimpl service;

	@GetMapping("/employee")

	public List<Employee> getemployeedetails() {

		List<Employee> obj = service.getemployeedetails();

		return obj;
	}
}
