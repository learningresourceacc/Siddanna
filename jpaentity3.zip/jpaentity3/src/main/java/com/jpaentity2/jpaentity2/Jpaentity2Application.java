package com.jpaentity2.jpaentity2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Jpaentity2Application {

	public static void main(String[] args) {
		SpringApplication.run(Jpaentity2Application.class, args);
	}

}
