package com.jpaentity2.jpaentity2.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jpaentity2.jpaentity2.entity.Department;
import com.jpaentity2.jpaentity2.entity.Employee;
import com.jpaentity2.jpaentity2.service.serviceimpl;

@RestController
public class controller {
	
	@Autowired
	private serviceimpl ser;

	@GetMapping("/employee")
	public List<Department> getemployee() {
		List<Department> obj=ser.getemployee();
		return obj;
	}
}