package com.jpaentity2.jpaentity2.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jpaentity2.jpaentity2.entity.Department;
import com.jpaentity2.jpaentity2.entity.Employee;
import com.jpaentity2.jpaentity2.repo.Departmentrepo;
import com.jpaentity2.jpaentity2.repo.Employeerepo;

@Service
public class serviceimpl {

	@Autowired
	private Departmentrepo departmentrepo;

	public List<Department> getemployee() {
		List<Department> result = departmentrepo.findAll();
		return result;
	}
}
