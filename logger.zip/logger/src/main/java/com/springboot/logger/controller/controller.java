package com.springboot.logger.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class controller {

	Logger logger = LoggerFactory.getLogger(controller.class);
	@GetMapping("/home")
	public String getmessage() {
		
		logger.trace("-hello");
		return "hello good morning";
	}
}
