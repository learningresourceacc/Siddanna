package com.jpaentity.jpaentityrelation.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.jpaentity.jpaentityrelation.entity.Employee;

@Repository
public interface Employeerepo extends JpaRepository<Employee,Integer>{

}
