package com.jpaentity.jpaentityrelation.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jpaentity.jpaentityrelation.entity.Employee;
import com.jpaentity.jpaentityrelation.service.Service;

@RestController
public class controller {
	
	@Autowired
	private Service ser;

	@GetMapping("/employee")
	public List<Employee> getemployee() {
		List<Employee> obj=ser.getemployee();
		return obj;
	}
}
