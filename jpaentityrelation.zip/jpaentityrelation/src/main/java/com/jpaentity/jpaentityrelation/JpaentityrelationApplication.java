package com.jpaentity.jpaentityrelation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaentityrelationApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpaentityrelationApplication.class, args);
	}

}
