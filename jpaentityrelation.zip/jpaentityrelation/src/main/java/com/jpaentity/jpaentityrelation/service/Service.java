package com.jpaentity.jpaentityrelation.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.jpaentity.jpaentityrelation.entity.Employee;
import com.jpaentity.jpaentityrelation.repository.Employeerepo;

@org.springframework.stereotype.Service
public class Service {

	@Autowired
	private Employeerepo employeerepo;
	
	

	public List<Employee> getemployee() {
		 List<Employee> result = employeerepo.findAll();
		return result;
	}
}
