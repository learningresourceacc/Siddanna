package com.springsecurity.example.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.springsecurity.example.entity.User;

@Repository
public interface Loginrepo extends JpaRepository<User,Integer> {

	User findByUsername(String username);
}
