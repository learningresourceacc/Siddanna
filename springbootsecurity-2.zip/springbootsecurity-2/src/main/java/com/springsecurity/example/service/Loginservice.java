package com.springsecurity.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springsecurity.example.repository.Loginrepo;

@Service
public class Loginservice {

	
	@Autowired
	private Loginrepo loginrepo;
	
	
}
