package com.springsecurity.example.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "User")
public class User {

	@Id
	private int id;
	private String username;
	private String userpassword;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUserpassword() {
		return userpassword;
	}

	public void setUserpassword(String userpassword) {
		this.userpassword = userpassword;
	}

	public User(int id, String username, String userpassword) {
		super();
		this.id = id;
		this.username = username;
		this.userpassword = userpassword;
	}

	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

}
